[[!meta title="NewsHub for NVDA — Pembaca Berita Multisitus"]]

* **Pembuat:** Aris Yohanes Elean, S.Kom
* **Versi:** 1.2.1
* **Versi NVDA yang Didukung:** 2022.1.0 – 2026.1.0

## Gambaran Umum

Membaca berita dari berbagai situs berita nasional maupun internasional seperti kompas.com, detik.com, dan sebagainya memang sangat menyenangkan. Selain berita yang disajikan dapat dipercaya, juga menambah pengetahuan kita sebagai pembaca.
Namun, sebagaimana yang kita ketahui, halaman situs-situs berita tersebut tidak bersahabat dengan pembaca layar karena banyaknya iklan dan navigasi yang menyulitkan.
Untuk itulah **"NewsHub For NVDA"** hadir!

Pada versi 1.2.1 ini, add-on mendukung penuh **5 portal berita utama Indonesia** dengan total **76 rubrik resmi**:

* **Kompas.com (23 Rubrik):** News, Nasional, Global, Megapolitan, Regional, Pemilu, IKN, Bola, Tekno, Otomotif, Entertainment, Sains, Health, Money, Tren, Properti, Lifestyle, Hype, Travel, Homey, Food, UMKM, Edukasi.
* **Detik.com (27 Rubrik):** Detik news, Detik finance, DetikInet, DetikHot, DetikSport, SepakBola, DetikOto, DetikTravel, DetikFood, Detik Health, Wolipop, DetikX, 20Detik, DetikFoto, DetikEdu, DetikHikmah, DetikProperti, DetikPop, DetikJateng, DetikJatim, DetikJabar, DetikSulsel, DetikSumut, DetikBali, DetikSumbagsel, DetikJogja, DetikKalimantan.
* **CNN Indonesia (8 Rubrik):** Nasional, Internasional, Ekonomi, Olahraga, Teknologi, Otomotif, Hiburan, Gaya hidup.
* **CNBC Indonesia (7 Rubrik):** Market, My Money, News, Tech, LifeStyle, Sharia, Entrepreneur.
* **Tempo.co (11 Rubrik):** Permainan baru, Politik, Hukum, Ekonomi, Lingkungan, Wawancara, Investigasi, Cek fakta, Tokoh, Newsletter, Info tempo.

## Pintasan Keyboard

| Pintasan | Tindakan |
| :--- | :--- |
| **NVDA+Shift+K** | Membuka dashboard NewsHub for NVDA dari mana saja |
| **Tab / Shift+Tab** | Berpindah antar-kontrol dalam 12 urutan fokus standar |
| **Panah Atas / Bawah** | Memilih situs berita, rubrik, atau judul artikel, serta membaca isi berita per baris |
| **Alt+[** | Artikel sebelumnya dalam daftar rubrik aktif |
| **Alt+]** | Artikel berikutnya dalam daftar rubrik aktif |
| **F5** | Memperbarui daftar berita pada rubrik aktif |
| **Ctrl+R** | Memuat ulang isi lengkap artikel yang sedang dipilih |
| **Alt+R** | Kembali ke kontrol pemilihan rubrik berita |
| **Alt+S** | Kembali ke kontrol pemilihan situs berita |
| **Escape** | Kembali ke tahap sebelumnya secara kontekstual atau menutup dashboard |
