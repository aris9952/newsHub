[[!meta title="NewsHub for NVDA"]]

* **Author:** Aris Yohanes Elean, S.Kom
* **Version:** 1.2.1
* **Supported NVDA Versions:** 2022.1.0 – 2026.1.0

## Overview

Reading news from various national and international news portals such as kompas.com, detik.com, and others is truly enjoyable. Aside from providing reliable information, it also broadens our knowledge as readers.
However, as we know, the web pages of these news portals are not friendly to screen readers.
There are many advertisements and complex navigation elements that make reading difficult.
That is why **"NewsHub For NVDA"** is here!

With this add-on, you can read news from trusted news portals easily and comfortably. In version 1.2.1, the add-on supports **5 major Indonesian news portals** across **76 official rubrics**:

* **Kompas.com (23 Rubrics):** News, Nasional, Global, Megapolitan, Regional, Pemilu, IKN, Bola, Tekno, Otomotif, Entertainment, Sains, Health, Money, Tren, Properti, Lifestyle, Hype, Travel, Homey, Food, UMKM, Edukasi.
* **Detik.com (27 Rubrics):** Detik news, Detik finance, DetikInet, DetikHot, DetikSport, SepakBola, DetikOto, DetikTravel, DetikFood, Detik Health, Wolipop, DetikX, 20Detik, DetikFoto, DetikEdu, DetikHikmah, DetikProperti, DetikPop, DetikJateng, DetikJatim, DetikJabar, DetikSulsel, DetikSumut, DetikBali, DetikSumbagsel, DetikJogja, DetikKalimantan.
* **CNN Indonesia (8 Rubrics):** Nasional, Internasional, Ekonomi, Olahraga, Teknologi, Otomotif, Hiburan, Gaya hidup.
* **CNBC Indonesia (7 Rubrics):** Market, My Money, News, Tech, LifeStyle, Sharia, Entrepreneur.
* **Tempo.co (11 Rubrics):** Permainan baru, Politik, Hukum, Ekonomi, Lingkungan, Wawancara, Investigasi, Cek fakta, Tokoh, Newsletter, Info tempo.

## Keyboard Shortcuts

| Shortcut | Action |
| :--- | :--- |
| **NVDA+Shift+K** | Open the NewsHub for NVDA dashboard from anywhere |
| **Tab / Shift+Tab** | Move focus across dashboard controls in the 12-step focus order |
| **Up / Down Arrow** | Select a news site, rubric, or article title, or read article content line by line |
| **Alt+[** | Go to the previous article in the active rubric list |
| **Alt+]** | Go to the next article in the active rubric list |
| **F5** | Refresh the article list for the active rubric |
| **Ctrl+R** | Reload the full content of the currently selected article |
| **Alt+R** | Return focus to the rubric selection control |
| **Alt+S** | Return focus to the news site selection control |
| **Escape** | Contextually return to the previous stage or close the dashboard |
