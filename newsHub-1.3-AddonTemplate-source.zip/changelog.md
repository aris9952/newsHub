Version 1.2.1:
- Migrated add-on structure to official NVDA AddonTemplate with native gettext localization (locale/id/LC_MESSAGES/nvda.po and nvda.mo).
- Bundled Mozilla CA certificate store (certs/cacert.pem) and automatic SSL verification fallback for standalone NVDA installations.
- Added anti-403 browser headers, session CookieJar persistence, Windows Schannel curl fallback, and Tempo.co RSS fallback.
- Full support for 5 major Indonesian news portals (76 rubrics): Kompas.com, Detik.com, CNN Indonesia, CNBC Indonesia, and Tempo.co.
