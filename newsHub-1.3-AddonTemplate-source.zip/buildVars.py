# -*- coding: utf-8 -*-
# Build customizations
# Change this file instead of sconstruct or manifest files, whenever possible.

from site_scons.site_tools.NVDATool.typings import AddonInfo, BrailleTables, SymbolDictionaries, SpeechDictionaries

# Since some strings in `addon_info` are translatable,
# we need to include them in the .po files.
# Gettext recognizes only strings given as parameters to the `_` function.
# To avoid initializing translations in this module we simply import a "fake" `_` function
# which returns whatever is given to it as an argument.
from site_scons.site_tools.NVDATool.utils import _

# Add-on information variables
addon_info = AddonInfo(
	# add-on Name/identifier, internal for NVDA
	addon_name="newsHub",
	# Add-on summary/title, usually the user visible name of the add-on
	# Translators: Summary/title for this add-on
	# to be shown on installation and add-on information found in add-on store
	addon_summary=_('NewsHub for NVDA'),
	# Add-on description
	# Translators: Long description to be shown for this add-on on add-on information from add-on store
	addon_description=_('Reading news from various national and international news portals such as kompas.com, detik.com, and others is truly enjoyable. Aside from providing reliable information, it also broadens our knowledge as readers.\nHowever, as we know, the web pages of these news portals are not friendly to screen readers.\nThere are many advertisements and complex navigation elements that make reading difficult.\nThat is why "NewsHub For NVDA" is here!\n\nWith this add-on, you can read news from trusted news portals easily and comfortably. In this version, the add-on supports Kompas.com (23 rubrics), Detik.com (27 rubrics), CNN Indonesia (8 rubrics), CNBC Indonesia (7 rubrics), and Tempo.co (11 rubrics), complete with cross-portal keyword search, an accessible HTML reading view with NVDA Browse Mode navigation, and inline HTML5 photo and video playback (<video> and <img>) directly inside the article view.\nHappy reading!\n\nKeyboard Shortcuts:\n- NVDA+Shift+K: Open the NewsHub for NVDA dashboard from anywhere.\n- Ctrl+F: Jump to the cross-portal keyword search box.\n- Tab / Shift+Tab: Navigate between controls in the dashboard.\n- Up / Down Arrow: Select a news site, rubric, or article title, or read article content in the HTML viewer.\n- H / K / T / G / L: Navigate headings, links, tables, graphics, and lists in the HTML article reading area (NVDA Browse Mode).\n- Alt+[: Navigate to the previous article in the active list.\n- Alt+]: Navigate to the next article in the active list.\n- F5: Refresh the article list for the active rubric or search.\n- Ctrl+R: Reload the full content of the currently selected article.\n- Alt+R: Return focus to the rubric selection control.\n- Alt+S: Return focus to the news site selection control.\n- Escape: Clear active search results and restore the default view, or contextually return to the previous stage / close the dashboard.'),
	# version
	addon_version="1.3.0",
	# Brief changelog for this version
	# Translators: what's new content for the add-on version to be shown in the add-on store
	addon_changelog=_('Version 1.3.0:\n- Added cross-portal news search by keyword across all 5 supported portals (Kompas.com, Detik.com, CNN Indonesia, CNBC Indonesia, and Tempo.co) with automatic hiding of site/rubric selectors during active search and Escape to restore the default view.\n- Replaced the plain text reading area with a standard HTML article viewer supporting full NVDA Browse Mode navigation (headings, paragraphs, lists, tables, links, and media).\n- Embedded article photos (<img> / <figure>) and videos (HTML5 <video controls> and embedded players) directly inline inside the HTML article reading view just like a web browser, without requiring a separate standalone video player.'),
	# Author(s)
	addon_author="Aris Yohanes Elean, S.Kom",
	# URL for the add-on documentation support
	addon_url="https://www.kompas.com",
	# URL for the add-on repository where the source code can be found
	addon_sourceURL="https://github.com/aris9952/newsHub",
	# Documentation file name
	addon_docFileName="readme.html",
	# Minimum NVDA version supported (e.g. "2019.3.0", minor version is optional)
	addon_minimumNVDAVersion="2022.1.0",
	# Last NVDA version supported/tested (e.g. "2024.4.0", ideally more recent than minimum version)
	addon_lastTestedNVDAVersion="2026.1.0",
	# Add-on update channel (default is None, denoting stable releases,
	# and for development releases, use "dev".)
	# Do not change unless you know what you are doing!
	addon_updateChannel=None,
	# Add-on license such as GPL 2
	addon_license="GPL v2",
	# URL for the license document the ad-on is licensed under
	addon_licenseURL="https://www.gnu.org/licenses/gpl-2.0.html",
)

# Define the python files that are the sources of your add-on.
pythonSources: list[str] = ["addon/globalPlugins/newsHub/*.py"]

# Files that contain strings for translation. Usually your python sources
i18nSources: list[str] = pythonSources + ["buildVars.py"]

# Files that will be ignored when building the nvda-addon file
excludedFiles: list[str] = []

# Base language for the NVDA add-on
baseLanguage: str = "en"

# Markdown extensions for add-on documentation
markdownExtensions: list[str] = ["markdown.extensions.tables"]

# Custom braille translation tables
brailleTables: BrailleTables = {}

# Custom speech symbol dictionaries
symbolDictionaries: SymbolDictionaries = {}

# Custom speech dictionaries
speechDictionaries: SpeechDictionaries = {}
