# NewsHub for NVDA (v1.3.0)

**Author:** Aris Yohanes Elean, S.Kom  
**License:** GPL v2  
**Minimum NVDA Version:** 2022.1.0  
**Last Tested NVDA Version:** 2026.1.0  

## Overview
Reading news from various national and international news portals such as kompas.com, detik.com, and others is truly enjoyable. Aside from providing reliable information, it also broadens our knowledge as readers.
However, as we know, the web pages of these news portals are not friendly to screen readers.
There are many advertisements and complex navigation elements that make reading difficult.
That is why **"NewsHub For NVDA"** is here!

With this add-on, you can read news from trusted news portals easily and comfortably. In version 1.3.0, the add-on supports **5 major Indonesian news portals (76 rubrics)**:
- **Kompas.com** (23 rubrics)
- **Detik.com** (27 rubrics)
- **CNN Indonesia** (8 rubrics)
- **CNBC Indonesia** (7 rubrics)
- **Tempo.co** (11 rubrics)

## What's New in Version 1.3.0
- **Cross-Portal News Search (`Ctrl+F`):** Search articles by keyword across all 5 supported news portals simultaneously. When search results are displayed, the News Portal and Rubric selection controls are automatically hidden; pressing `Escape` clears the search results and restores the default view.
- **Standard HTML Reading View with Full NVDA Browse Mode Navigation:** The full article reading area is a standard HTML document view (`wx.html2.WebView` with automatic Win32 inner browser focus redirection and NVDA VirtualBuffer activation), allowing you to read and navigate articles using standard NVDA Browse Mode commands (`Up`/`Down Arrow`, `H` for headings, `K` for links, `T` for tables, `G` for graphics, `L` for lists) just like reading in a web browser.
- **Inline HTML5 Video (`<video controls>`) and Photo (`<img>` / `<figure>`) Display:** Photos and videos inside news articles are rendered directly inline inside the HTML reading area—just like a web browser—so you can read photo captions and play HTML5 `<video>` streams or embedded players directly in place without opening a separate video player window.

## Keyboard Shortcuts
- **NVDA+Shift+K**: Open the NewsHub for NVDA dashboard from anywhere.
- **Ctrl+F**: Jump to the cross-portal keyword search box.
- **Tab / Shift+Tab**: Navigate between controls in the dashboard.
- **Up / Down Arrow**: Select a news site, rubric, or article title, or read article content line by line in the HTML viewer.
- **H / K / T / G / L**: Navigate headings, links, tables, graphics, and lists inside the HTML article reading area (NVDA Browse Mode).
- **Alt+[**: Navigate to the previous article in the active list.
- **Alt+]**: Navigate to the next article in the active list.
- **F5**: Refresh the article list for the active rubric or search.
- **Ctrl+R**: Reload the full content of the currently selected article.
- **Alt+R**: Return focus to the rubric selection control.
- **Alt+S**: Return focus to the news site selection control.
- **Escape**: Clear active search results and restore the default view, or contextually return to the previous stage / close the dashboard.
